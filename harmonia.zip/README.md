# Harmonia

Repositório gerado para deploy no Vercel/GitHub.

**Nome do repositório:** `harmonia`  
**Usuário sugerido:** `matheusmr1226-cmd`

## Como usar (local)

```bash
npm install
npm run dev
```

Acesse: http://localhost:5173

## Deploy no Vercel

1. Crie repositório no GitHub com o conteúdo desta pasta (ou faça upload).
2. No Vercel, escolha **Import Git Repository** e selecione `matheusmr1226-cmd/harmonia`.
3. Configurações:
   - Framework Preset: **Vite**
   - Build Command: `npm run build`
   - Output Directory: `dist`
4. Deploy!

