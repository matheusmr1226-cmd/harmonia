import React, { useRef, useState, useEffect } from 'react';

const sampleTracks = [
  {
    id:1,
    title:'SoundHelix Song 1',
    artist:'Sample Artist',
    src:'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
    cover:'https://picsum.photos/seed/1/300/300'
  },
  {
    id:2,
    title:'SoundHelix Song 2',
    artist:'Sample Artist 2',
    src:'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3',
    cover:'https://picsum.photos/seed/2/300/300'
  },
  {
    id:3,
    title:'Acoustic Loop',
    artist:'Loop Band',
    src:'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3',
    cover:'https://picsum.photos/seed/3/300/300'
  }
];

export default function App(){
  const audioRef = useRef(null);
  const [queue, setQueue] = useState(sampleTracks);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [volume, setVolume] = useState(0.8);
  const [offlineMode, setOfflineMode] = useState(false);

  useEffect(()=>{
    const audio = audioRef.current;
    if(!audio) return;
    audio.volume = volume;
    const onTime = ()=>{
      setProgress((audio.currentTime / audio.duration) * 100 || 0);
    }
    const onEnd = ()=>{
      next();
    }
    audio.addEventListener('timeupdate', onTime);
    audio.addEventListener('ended', onEnd);
    return ()=>{
      audio.removeEventListener('timeupdate', onTime);
      audio.removeEventListener('ended', onEnd);
    }
  },[volume, currentIndex]);

  useEffect(()=>{
    const audio = audioRef.current;
    if(!audio) return;
    if(playing) audio.play().catch(()=>{}); else audio.pause();
  },[playing,currentIndex]);

  function playPause(){
    setPlaying(p=>!p);
  }

  function playIndex(i){
    setCurrentIndex(i);
    setPlaying(true);
  }

  function next(){
    setCurrentIndex(i=> (i+1) % queue.length);
    setPlaying(true);
  }

  function prev(){
    setCurrentIndex(i=> (i-1 + queue.length) % queue.length);
    setPlaying(true);
  }

  function seek(percent){
    const audio = audioRef.current;
    if(!audio) return;
    audio.currentTime = (percent/100) * audio.duration;
    setProgress(percent);
  }

  return (
    <div className="min-h-screen px-6 py-8">
      <div className="max-w-6xl mx-auto grid grid-cols-12 gap-6">
        <aside className="col-span-3">
          <div className="p-4 rounded-xl bg-gradient-to-br from-[#091226] to-[#071726]">
            <div className="flex items-center gap-3 mb-4">
              <div className="h-12 w-12 rounded-full bg-gradient-to-tr from-blue-400 to-indigo-600 flex items-center justify-center font-bold">H</div>
              <div>
                <div className="text-lg font-semibold">Harmonia</div>
                <div className="text-xs opacity-70">Música grátis • Sem anúncios</div>
              </div>
            </div>

            <nav className="flex flex-col gap-2 text-sm">
              <button className="text-left py-2 px-3 rounded-lg hover:bg-white/5">Início</button>
              <button className="text-left py-2 px-3 rounded-lg hover:bg-white/5">Descobrir</button>
              <button className="text-left py-2 px-3 rounded-lg hover:bg-white/5">Minhas playlists</button>
              <button className="text-left py-2 px-3 rounded-lg hover:bg-white/5">Downloads</button>
            </nav>

            <div className="mt-6 text-xs opacity-80 flex items-center justify-between">
              <div>Modo offline</div>
              <label className="inline-flex relative items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" checked={offlineMode} onChange={()=>setOfflineMode(s=>!s)} />
                <div className="w-11 h-6 bg-gray-200 rounded-full peer-checked:bg-blue-500"></div>
              </label>
            </div>
          </div>
        </aside>

        <main className="col-span-6">
          <header className="mb-4 flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold">Descobrir</h1>
              <p className="text-sm opacity-70">Sugestões e playlists geradas</p>
            </div>
            <div className="flex items-center gap-3">
              <input placeholder="Buscar músicas, artistas ou playlists" className="w-72 rounded-full py-2 px-4 bg-white/5 outline-none" />
              <button className="px-3 py-2 rounded-full bg-blue-500">Login</button>
            </div>
          </header>

          <section className="grid grid-cols-2 gap-4">
            {queue.map((t, i) => (
              <div key={t.id} className="bg-white/5 rounded-xl p-3 flex items-center gap-3">
                <img src={t.cover} alt="" className="h-14 w-14 rounded-md object-cover" />
                <div className="flex-1">
                  <div className="font-semibold">{t.title}</div>
                  <div className="text-xs opacity-70">{t.artist}</div>
                </div>
                <div className="flex flex-col gap-2">
                  <button onClick={()=>playIndex(i)} className="text-xs py-1 px-2 rounded bg-white/6">▶</button>
                </div>
              </div>
            ))}
          </section>
        </main>

        <aside className="col-span-3">
          <div className="bg-white/5 rounded-xl p-4">
            <div className="text-sm opacity-80">Fila de reprodução</div>
            <ul className="mt-2 space-y-2 max-h-48 overflow-auto">
              {queue.map((t, i) => (
                <li key={t.id} className={`flex items-center justify-between text-sm ${i===currentIndex? 'bg-white/6 rounded p-2':''}`}>
                  <div className="flex items-center gap-3">
                    <img src={t.cover} alt="" className="h-8 w-8 rounded-md object-cover" />
                    <div>
                      <div>{t.title}</div>
                      <div className="text-xs opacity-60">{t.artist}</div>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button onClick={()=>playIndex(i)} className="text-xs py-1 px-2 rounded bg-white/6">Tocar</button>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </aside>

        <audio ref={audioRef} src={queue[currentIndex].src} preload="auto" />
        <div className="col-span-12 fixed left-0 right-0 bottom-0 px-6 py-3 bg-gradient-to-t from-black/80 to-transparent">
          <div className="max-w-6xl mx-auto flex items-center gap-4">
            <img src={queue[currentIndex].cover} alt="" className="h-12 w-12 rounded-md object-cover" />
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-semibold">{queue[currentIndex].title}</div>
                  <div className="text-xs opacity-70">{queue[currentIndex].artist}</div>
                </div>
                <div className="text-xs opacity-60">{/* duration */}</div>
              </div>
              <div className="mt-2">
                <input value={progress} onChange={(e)=>seek(e.target.value)} type="range" min="0" max="100" className="w-full" />
              </div>
            </div>

            <div className="flex items-center gap-3">
              <button onClick={prev} className="rounded-full p-3 bg-white/6">⏮</button>
              <button onClick={playPause} className="rounded-full p-4 bg-gradient-to-tr from-blue-400 to-indigo-600 text-black font-bold">{playing? '⏸' : '▶'}</button>
              <button onClick={next} className="rounded-full p-3 bg-white/6">⏭</button>
              <input type="range" min="0" max="1" step="0.01" value={volume} onChange={(e)=>setVolume(Number(e.target.value))} className="w-24 ml-3" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
