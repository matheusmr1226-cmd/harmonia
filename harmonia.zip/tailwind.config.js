module.exports = {
  content: ['./index.html','./src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      colors: {
        'harmonia-dark-1': '#0A0F1F',
        'harmonia-dark-2': '#0F1B2E',
        'harmonia-blue': '#3BAEF8'
      }
    }
  },
  plugins: []
}
